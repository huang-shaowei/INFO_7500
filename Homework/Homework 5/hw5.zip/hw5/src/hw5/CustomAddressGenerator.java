package hw5;

import org.bitcoinj.core.ECKey;

public class CustomAddressGenerator {

	/*  @param prefix	string of letters in base58 encoding
	 *  @returns 		a Bitcoin address on mainnet which starts with 1 followed prefix.
     */
	public static String get(String prefix) {
		return null;
	}

}

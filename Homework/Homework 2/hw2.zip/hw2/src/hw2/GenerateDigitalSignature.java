package hw2;

public class GenerateDigitalSignature {

	public static void main(String[] args) throws Throwable {

	}

}

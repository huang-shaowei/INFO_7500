package hw2;

public class GenerateScroogeKeyPair {

	public static void main(String[] args) throws Exception {

	}
}
